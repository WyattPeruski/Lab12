import java.util.ArrayList;
import java.util.List;

public class CarApp {
public static void main(String[] args) {
	int carInput;
	
	List<Car> list = new ArrayList<>();
	list.add(new Car("Chevy", "impala", 2010, 20100.90));
	System.out.println(list);
}
}
 